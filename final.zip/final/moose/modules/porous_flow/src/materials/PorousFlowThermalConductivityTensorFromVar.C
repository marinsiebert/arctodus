//* This file is part of the MOOSE framework
//* https://www.mooseframework.org
//*
//* All rights reserved, see COPYRIGHT for full restrictions
//* https://github.com/idaholab/moose/blob/master/COPYRIGHT
//*
//* Licensed under LGPL 2.1, please see LICENSE for details
//* https://www.gnu.org/licenses/lgpl-2.1.html

#include "PorousFlowThermalConductivityTensorFromVar.h"

registerMooseObject("PorousFlowApp", PorousFlowThermalConductivityTensorFromVar);

InputParameters
PorousFlowThermalConductivityTensorFromVar::validParams()
{
  InputParameters params = PorousFlowThermalConductivityBase::validParams();
  params.addRequiredCoupledVar("lambda", "The scalar thermal conductivity");
  params.addParam<RealTensorValue>("anisotropy",
                                   "A tensor to multiply the scalar "
                                   "thermal conductivity, in order to obtain anisotropy if "
                                   "required. Defaults to isotropic thermal conductivity "
                                   "if not specified.");
  params.addClassDescription(
      "This Material calculates the thermal conductivity tensor from a coupled variable "
      "multiplied by a tensor");
  return params;
}

PorousFlowThermalConductivityTensorFromVar::PorousFlowThermalConductivityTensorFromVar(
    const InputParameters & parameters)
  : PorousFlowThermalConductivityBase(parameters),
    _lambda(coupledValue("lambda")),
    _anisotropy(parameters.isParamValid("anisotropy")
                      ? getParam<RealTensorValue>("anisotropy")
                      : RealTensorValue(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0))
{
}

void
PorousFlowThermalConductivityTensorFromVar::computeQpProperties()
{
  _la_qp[_qp] = _anisotropy * _lambda[_qp];

  (_dla_qp_dvar)[_qp].resize(_num_var, RealTensorValue());
  //(*_dla_qp_dgradvar)[_qp].resize(LIBMESH_DIM);

//  for (const auto i : make_range(Moose::dim))
//    (*_dla_qp_dgradvar)[_qp][i].resize(_num_var, RealTensorValue());
}
